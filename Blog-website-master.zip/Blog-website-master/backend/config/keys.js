
module.exports = require('./dev')